#pragma once
extern int MOD;
int pnorm(int);
int padd(int, int);
int psub(int, int);
int pmul(int, int);
int pdiv(int, int);