#pragma once
#ifndef PRIMES_9183746069462
#define PRIMES_9183746069462
int isPrime(int x);
int findNextPrime(int x);
int getPrimesCount(int l, int r);
#endif